extends Sprite2D
## A lightning bolt shot by the purple monster. Flies straight at where you were.
## Touching it = -10 HP.

signal hit_player(damage: int)

const DAMAGE := 10
const SPEED := 150.0
const HIT_RADIUS := 13.0
const LIFETIME := 5.0
const STREAK_ANGLE := -0.656     # direction the streak is drawn in the sheet (up-right)
const ANIM_FPS := 14.0

var player: Node2D = null
var vel := Vector2.ZERO
var age := 0.0


func setup(p: Node2D, from: Vector2, dir: Vector2) -> void:
	player = p
	position = from
	vel = dir * SPEED
	rotation = dir.angle() - STREAK_ANGLE
	z_index = 500


func _ready() -> void:
	add_to_group("hazards")


func freeze() -> void:
	set_process(false)


func _process(delta: float) -> void:
	age += delta
	position += vel * delta
	frame = 6 + int(age * ANIM_FPS) % 4
	if player != null and global_position.distance_to(player.global_position) < HIT_RADIUS:
		hit_player.emit(DAMAGE)
		queue_free()
		return
	if age > LIFETIME:
		queue_free()
