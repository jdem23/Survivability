extends Node2D
## A little swamp witch that hovers nearby and throws poison vials.
signal throw_vial(from_pos: Vector2)
const FIRE_INTERVAL := 2.8
var player: Node2D
var level_width := 5400.0
var base_y := 75.0
var fire_timer := 1.4
var age := 0.0
var hp := 2
var dead := false
func setup(p: Node2D, y: float, lw: float) -> void:
	player = p
	base_y = y
	level_width = lw
func _ready() -> void:
	add_to_group("enemies")
	add_to_group("hazards")
	z_index = 25
	queue_redraw()
func freeze() -> void:
	set_process(false)
func take_hit(dmg: int) -> void:
	if dead: return
	hp -= dmg
	if hp <= 0:
		dead = true
		remove_from_group("enemies")
		remove_from_group("hazards")
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 0.0, 0.2)
		tw.tween_callback(queue_free)
	else:
		modulate = Color(2.0, 2.0, 2.0, 1.0)
		create_tween().tween_property(self, "modulate", Color.WHITE, 0.2)
func _process(delta: float) -> void:
	if player == null: return
	age += delta
	position.x = lerpf(position.x, minf(player.global_position.x + 170.0, level_width - 35.0), 1.0 - exp(-1.8 * delta))
	position.y = base_y + sin(age * 2.3) * 7.0
	fire_timer -= delta
	if fire_timer <= 0.0:
		fire_timer = FIRE_INTERVAL
		throw_vial.emit(global_position + Vector2(-8.0, 5.0))
	queue_redraw()
func _draw() -> void:
	# Hand-drawn cartoon witch: hat, face, cloak, and glowing eyes.
	draw_colored_polygon(PackedVector2Array([Vector2(-13,-5),Vector2(13,-5),Vector2(9,13),Vector2(-9,13)]), Color(0.22,0.12,0.32))
	draw_circle(Vector2(0,-7), 8.0, Color(0.48,0.72,0.43))
	draw_colored_polygon(PackedVector2Array([Vector2(-13,-12),Vector2(13,-12),Vector2(3,-28),Vector2(-2,-28)]), Color(0.15,0.08,0.22))
	draw_rect(Rect2(-15,-13,30,3), Color(0.10,0.05,0.16))
	draw_circle(Vector2(-3,-8), 1.5, Color(0.95,1.0,0.15))
	draw_circle(Vector2(3,-8), 1.5, Color(0.95,1.0,0.15))
	draw_line(Vector2(-4,-1), Vector2(4,-1), Color(0.18,0.08,0.12), 1.5)
	draw_circle(Vector2(12,4), 4.0, Color(0.25,1.0,0.12,0.85))
