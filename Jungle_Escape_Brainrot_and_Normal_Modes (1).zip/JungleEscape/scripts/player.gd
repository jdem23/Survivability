extends CharacterBody2D
## Explorer. Joystick / WASD to move; tap or click anywhere outside the joystick to swing.

const RUN_SPEED := 90.0
const ACCEL := 900.0
const GRAVITY := 520.0
const THRUST := 1100.0
const MAX_RISE := 120.0
const MAX_FALL := 280.0
const LEVEL_WIDTH := 5400.0
const MIN_X := 16.0
const SPRITE_BASE_Y := 14.0         # sprite pivot = the explorer's feet
const FACES_RIGHT := true           # set to false if the sprite looks backwards
const SWORD_RANGE := 46.0
const ATTACK_COOLDOWN := 0.35
const HURT_INVULN := 1.0

var brainrot_mode := false
var joystick = null                 # assigned by main.gd
var dead := false
var finished := false
var facing := 1
var attack_cd := 0.0
var invuln := 0.0
var air_time := 0.0
var last_vy := 0.0
var bob := 0.0
var squash_tween: Tween

@onready var sprite: Sprite2D = $Sprite
@onready var sword = $SwordPivot
@onready var farts = get_node_or_null("Farts")
@onready var pee = get_node_or_null("Pee")
@onready var fart_sfx = get_node_or_null("FartSfx")
@onready var pee_sfx = get_node_or_null("PeeSfx")



func _ready() -> void:
	# These nodes are created in code so both modes share one player scene.
	var puff: Texture2D = load("res://assets/Puff.png")
	farts = CPUParticles2D.new()
	farts.name = "Farts"
	farts.position = Vector2(0, 12)
	farts.texture = puff
	farts.amount = 24
	farts.lifetime = 0.55
	farts.direction = Vector2(0, 1)
	farts.spread = 25.0
	farts.gravity = Vector2(0, -15)
	farts.initial_velocity_min = 25.0
	farts.initial_velocity_max = 45.0
	farts.scale_amount_min = 0.5
	farts.scale_amount_max = 1.1
	farts.color = Color(0.48, 0.29, 0.12, 0.8)
	farts.emitting = false
	add_child(farts)
	pee = CPUParticles2D.new()
	pee.name = "Pee"
	pee.position = Vector2(7, 4)
	pee.texture = puff
	pee.amount = 60
	pee.lifetime = 0.7
	pee.direction = Vector2(1, -0.25)
	pee.spread = 5.0
	pee.gravity = Vector2(0, 320)
	pee.initial_velocity_min = 85.0
	pee.initial_velocity_max = 110.0
	pee.scale_amount_min = 0.35
	pee.scale_amount_max = 0.6
	pee.color = Color(1, 0.9, 0.1, 1)
	pee.emitting = false
	add_child(pee)
	fart_sfx = AudioStreamPlayer.new()
	fart_sfx.stream = load("res://assets/Fart.mp3")
	fart_sfx.volume_db = -4.0
	add_child(fart_sfx)
	pee_sfx = AudioStreamPlayer.new()
	pee_sfx.stream = load("res://assets/Pee.mp3")
	pee_sfx.volume_db = -2.0
	add_child(pee_sfx)


func _read_input() -> Vector2:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if dir == Vector2.ZERO and joystick != null:
		dir = joystick.output
	return dir


func _physics_process(delta: float) -> void:
	attack_cd = maxf(attack_cd - delta, 0.0)
	if invuln > 0.0:
		invuln -= delta
		sprite.modulate.a = 0.35 if int(invuln * 14.0) % 2 == 0 else 1.0
		if invuln <= 0.0:
			sprite.modulate = Color.WHITE

	if dead or finished:
		velocity.x = 0.0
		velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)
		move_and_slide()
		return

	var dir := _read_input()
	var thrusting := dir.y < -0.35
	velocity.x = move_toward(velocity.x, dir.x * RUN_SPEED, ACCEL * delta)
	if thrusting:
		velocity.y = maxf(velocity.y - THRUST * delta, -MAX_RISE)
	else:
		velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)

	last_vy = velocity.y
	var was_on_floor := is_on_floor()
	move_and_slide()
	var on_floor := is_on_floor()

	position.x = clampf(position.x, MIN_X, LEVEL_WIDTH - 16.0)
	if position.y < -30.0:
		position.y = -30.0

	# landing squash
	if on_floor and not was_on_floor and air_time > 0.12 and last_vy > 90.0:
		_squash(clampf(last_vy / 260.0, 0.2, 0.5))
	air_time = 0.0 if on_floor else air_time + delta

	# facing
	if absf(dir.x) > 0.2:
		facing = 1 if dir.x > 0.0 else -1
		sprite.flip_h = (facing < 0) if FACES_RIGHT else (facing > 0)

	# Brainrot-only effects; normal mode stays completely quiet and clean.
	var moving_h := absf(velocity.x) > 20.0
	if farts != null:
		farts.emitting = brainrot_mode and (moving_h or thrusting)
	if fart_sfx != null:
		if brainrot_mode and (moving_h or thrusting):
			if not fart_sfx.playing: fart_sfx.play()
		elif fart_sfx.playing:
			fart_sfx.stop()
	if on_floor and moving_h:
		bob += delta * 16.0
		sprite.position.y = SPRITE_BASE_Y - absf(sin(bob)) * 2.0
	else:
		bob = 0.0
		sprite.position.y = SPRITE_BASE_Y


# ---------------------------------------------------------------- actions
func _squash(strength: float) -> void:
	if squash_tween != null:
		squash_tween.kill()
	sprite.scale = Vector2(1.0 + strength, 1.0 - strength)
	squash_tween = create_tween()
	squash_tween.tween_property(sprite, "scale", Vector2.ONE, 0.2) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _unhandled_input(event: InputEvent) -> void:
	if dead or finished:
		return
	if event.is_action_pressed("attack"):
		attack()
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if joystick != null and joystick.touching_stick():
			return
		attack()
	elif event is InputEventScreenTouch and event.pressed:
		if joystick != null and event.position.distance_to(joystick.global_position) <= 42.0:
			return
		attack()


func attack() -> void:
	if attack_cd > 0.0 or dead or finished:
		return
	attack_cd = ATTACK_COOLDOWN
	sword.swing(facing)
	await get_tree().create_timer(0.07).timeout
	if dead or finished:
		return
	var origin := global_position + Vector2(0, 2)
	for e in get_tree().get_nodes_in_group("enemies"):
		var d: Vector2 = e.global_position - origin
		if d.length() < SWORD_RANGE and d.x * facing > -8.0:
			e.take_hit(1)


func hurt() -> void:
	invuln = HURT_INVULN
	if brainrot_mode and pee != null and pee_sfx != null:
		pee.emitting = true
		pee_sfx.play()
		get_tree().create_timer(1.4).timeout.connect(func():
			if is_instance_valid(pee): pee.emitting = false
			if is_instance_valid(pee_sfx): pee_sfx.stop())
	sprite.modulate = Color(1.0, 0.5, 0.5, 1.0)


func is_invulnerable() -> bool:
	return invuln > 0.0


func die() -> void:
	dead = true
	sprite.modulate = Color(0.4, 0.4, 0.4, 1.0)
	var tw := create_tween()
	tw.tween_property(sprite, "rotation", facing * PI / 2.0, 0.3)


func finish() -> void:
	finished = true
	sprite.modulate = Color.WHITE
	_squash(0.3)

func set_brainrot_effects(enabled: bool) -> void:
	brainrot_mode = enabled
	if farts != null: farts.emitting = false
	if pee != null: pee.emitting = false
	if fart_sfx != null: fart_sfx.stop()
	if pee_sfx != null: pee_sfx.stop()
