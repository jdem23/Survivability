extends Sprite2D
## Purple monster. Hovers ahead of you on the right, flashes, then shoots a lightning
## bolt at you. Fires a few shots and leaves. Two sword hits kill it.

signal fire_bolt(from_pos: Vector2)

const SHOTS := 4
const SHOT_INTERVAL := 1.3
const FOLLOW_AHEAD := 125.0
const ANIM_FPS := 8.0
const FRAME_COUNT := 10
const BASE_TINT := Color(0.72, 0.45, 1.0, 1.0)

var player: Node2D = null
var level_width := 5400.0
var base_y := 80.0
var hp := 2
var t := 0.0
var shot_timer := 1.2
var shots_fired := 0
var leaving := false
var dying := false
var anim_t := 0.0


func setup(p: Node2D, y: float, lw: float) -> void:
	player = p
	base_y = y
	level_width = lw
	z_index = 20


func _ready() -> void:
	add_to_group("enemies")
	add_to_group("hazards")
	modulate = BASE_TINT


func freeze() -> void:
	set_process(false)


func take_hit(dmg: int) -> void:
	if dying:
		return
	hp -= dmg
	if hp <= 0:
		dying = true
		remove_from_group("enemies")
		remove_from_group("hazards")
		set_process(false)
		var tw := create_tween()
		tw.tween_property(self, "scale", Vector2(1.6, 1.6), 0.15)
		tw.parallel().tween_property(self, "modulate:a", 0.0, 0.15)
		tw.tween_callback(queue_free)
	else:
		modulate = Color(2.0, 2.0, 2.0, 1.0)
		create_tween().tween_property(self, "modulate", BASE_TINT, 0.15)


func _process(delta: float) -> void:
	t += delta
	anim_t += delta * ANIM_FPS
	frame = int(anim_t) % FRAME_COUNT

	if leaving:
		position += Vector2(110.0, -25.0) * delta
		if position.x > player.global_position.x + 330.0:
			queue_free()
		return

	var tx := minf(player.global_position.x + FOLLOW_AHEAD, level_width - 20.0)
	var target := Vector2(tx, base_y + sin(t * 2.0) * 10.0)
	position = position.lerp(target, 1.0 - exp(-3.0 * delta))

	shot_timer -= delta
	self_modulate = Color(2.2, 2.2, 2.2, 1.0) if shot_timer < 0.3 else Color.WHITE   # warning flash
	if shot_timer <= 0.0:
		shot_timer = SHOT_INTERVAL
		shots_fired += 1
		fire_bolt.emit(global_position)
		if shots_fired >= SHOTS:
			leaving = true
			self_modulate = Color.WHITE
