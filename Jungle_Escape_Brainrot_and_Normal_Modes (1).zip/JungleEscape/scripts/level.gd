extends Node2D
## Builds the level every run: crates you can stand on, crates covered in spikes,
## spike patches on the floor, spiked walls (hanging from the top or rising from the
## floor, covering about half the screen height) and a spiked ceiling.
## Touching any spike = death (main.gd checks `spike_rects`).

const LEVEL_WIDTH := 5400.0
const GROUND_Y := 166.0
const SPIKE := 16.0
const CRATE := 26.0
const WALL_W := 24.0
const WALL_H := 70.0       # + 16 px of spikes on the free end = about half the field

var crate_scene: PackedScene = preload("res://scenes/Crate.tscn")
var spike_tex: Texture2D = preload("res://assets/Spike.png")
var wall_tex: Texture2D = preload("res://assets/WallTile.png")

var spike_rects: Array[Rect2] = []   # deadly zones
var block_rects: Array[Rect2] = []   # areas the sacks must not spawn in
var acid_rects: Array[Rect2] = []

var _strips: Array = []              # [position, rotation, length, drawn_behind]
var _wall_bodies: Array[Rect2] = []
var rng := RandomNumberGenerator.new()


func build() -> void:
	rng.randomize()
	# Sparse ceiling hazards: short clusters with generous safe gaps, not a continuous ceiling.
	var ceiling_x := rng.randf_range(210.0, 390.0)
	while ceiling_x < LEVEL_WIDTH - 220.0:
		var ceiling_w := rng.randf_range(24.0, 64.0)
		_add_strip(Rect2(ceiling_x, 0.0, ceiling_w, SPIKE), "down", true)
		ceiling_x += ceiling_w + rng.randf_range(190.0, 390.0)
	# Acid pools are placed on the floor with safe gaps between them.
	var acid_x := rng.randf_range(520.0, 760.0)
	while acid_x < LEVEL_WIDTH - 300.0:
		var acid_w := rng.randf_range(48.0, 94.0)
		acid_rects.append(Rect2(acid_x, GROUND_Y - 9.0, acid_w, 9.0))
		acid_x += acid_w + rng.randf_range(310.0, 520.0)
	var x := 380.0                                                   # safe start area
	var wall_from_top := rng.randf() < 0.5
	while x < LEVEL_WIDTH - 450.0:                                   # safe finish area
		var roll := rng.randf()
		var used := 0.0
		if roll < 0.28:
			used = _crate_cluster(x)
		elif roll < 0.48:
			used = _floor_spikes(x)
		elif roll < 0.66:
			used = _wall(x, wall_from_top)
			wall_from_top = not wall_from_top
		elif roll < 0.84:
			used = _floating_crates(x)
		else:
			used = _spiked_ground_crate(x)
		x += used + rng.randf_range(150.0, 250.0)
	queue_redraw()


func is_blocked(p: Vector2) -> bool:
	for r in block_rects:
		if r.has_point(p):
			return true
	return false


# ------------------------------------------------------------ pieces
func _crate_cluster(x: float) -> float:
	var half := CRATE / 2.0
	var base_y := GROUND_Y - half
	var width := CRATE
	var kind := rng.randi_range(0, 4)
	if kind == 0:                                  # single crate
		_add_crate(Vector2(x + half, base_y), false)
	elif kind == 1:                                # two side by side
		_add_crate(Vector2(x + half, base_y), false)
		_add_crate(Vector2(x + half + CRATE, base_y), false)
		width = CRATE * 2.0
	elif kind == 2:                                # tower of 2-3
		for j in rng.randi_range(2, 3):
			_add_crate(Vector2(x + half, base_y - j * CRATE), false)
	elif kind == 3:                                # pyramid
		_add_crate(Vector2(x + half, base_y), false)
		_add_crate(Vector2(x + half + CRATE, base_y), false)
		_add_crate(Vector2(x + CRATE, base_y - CRATE), false)
		width = CRATE * 2.0
	else:                                          # staircase
		for col in 3:
			for j in col + 1:
				_add_crate(Vector2(x + half + col * CRATE, base_y - j * CRATE), false)
		width = CRATE * 3.0
	return width


func _spiked_ground_crate(x: float) -> float:
	var half := CRATE / 2.0
	_add_crate(Vector2(x + SPIKE + half, GROUND_Y - half - 1.0), true)
	return CRATE + SPIKE * 2.0


func _floating_crates(x: float) -> float:
	var count := rng.randi_range(1, 3)
	for i in count:
		var cx := x + SPIKE + CRATE / 2.0 + i * 76.0
		var cy := rng.randf_range(78.0, 126.0)
		_add_crate(Vector2(cx, cy), rng.randf() < 0.3)
	return count * 76.0


func _floor_spikes(x: float) -> float:
	var w := SPIKE * rng.randi_range(2, 5)
	_add_strip(Rect2(x, GROUND_Y - SPIKE, w, SPIKE), "up", false)
	return w


func _wall(x: float, from_top: bool) -> float:
	var wx := x + SPIKE
	var body: Rect2
	if from_top:
		body = Rect2(wx, 0.0, WALL_W, WALL_H)
		_add_strip(Rect2(wx, WALL_H, WALL_W, SPIKE), "down", false)
	else:
		body = Rect2(wx, GROUND_Y - WALL_H, WALL_W, WALL_H)
		_add_strip(Rect2(wx, GROUND_Y - WALL_H - SPIKE, WALL_W, SPIKE), "up", false)
	_wall_bodies.append(body)
	spike_rects.append(body.grow(-1.0))
	block_rects.append(body.grow(30.0))
	_add_strip(Rect2(wx - SPIKE, body.position.y, SPIKE, WALL_H), "left", false)
	_add_strip(Rect2(wx + WALL_W, body.position.y, SPIKE, WALL_H), "right", false)
	return WALL_W + SPIKE * 2.0


func _add_crate(center: Vector2, spiked: bool) -> void:
	var c = crate_scene.instantiate()
	c.position = center
	add_child(c)
	var half := CRATE / 2.0
	block_rects.append(Rect2(center - Vector2(half, half), Vector2(CRATE, CRATE)).grow(22.0))
	if spiked:
		c.modulate = Color(1.0, 0.8, 0.8)
		_add_strip(Rect2(center.x - half, center.y - half - SPIKE, CRATE, SPIKE), "up", false)
		_add_strip(Rect2(center.x - half, center.y + half, CRATE, SPIKE), "down", false)
		_add_strip(Rect2(center.x - half - SPIKE, center.y - half, SPIKE, CRATE), "left", false)
		_add_strip(Rect2(center.x + half, center.y - half, SPIKE, CRATE), "right", false)


## Adds a row of spikes that fills world rect `r`, pointing in `facing`.
func _add_strip(r: Rect2, facing: String, behind: bool) -> void:
	var pos := Vector2.ZERO
	var rot := 0.0
	var length := 0.0
	var hit := Rect2()
	if facing == "up":
		pos = Vector2(r.position.x, r.position.y + r.size.y)
		length = r.size.x
		hit = Rect2(r.position.x + 2.0, r.position.y + 4.0, r.size.x - 4.0, r.size.y - 4.0)
	elif facing == "down":
		pos = Vector2(r.position.x + r.size.x, r.position.y)
		rot = PI
		length = r.size.x
		hit = Rect2(r.position.x + 2.0, r.position.y, r.size.x - 4.0, r.size.y - 4.0)
	elif facing == "left":
		pos = Vector2(r.position.x + r.size.x, r.position.y + r.size.y)
		rot = -PI / 2.0
		length = r.size.y
		hit = Rect2(r.position.x + 4.0, r.position.y + 2.0, r.size.x - 4.0, r.size.y - 4.0)
	else:  # right
		pos = r.position
		rot = PI / 2.0
		length = r.size.y
		hit = Rect2(r.position.x, r.position.y + 2.0, r.size.x - 4.0, r.size.y - 4.0)
	_strips.append([pos, rot, length, behind])
	spike_rects.append(hit)
	if not behind:
		block_rects.append(r.grow(18.0))


# ------------------------------------------------------------ drawing
func _draw() -> void:
	# Glowing green acid pools with bright bubbles/ripples.
	for i in acid_rects.size():
		var a: Rect2 = acid_rects[i]
		draw_rect(a.grow(2.0), Color(0.10, 0.55, 0.12, 0.55), true)
		draw_rect(a, Color(0.20, 0.95, 0.08, 0.95), true)
		for bubble in 3:
			var bx := a.position.x + a.size.x * float(bubble + 1) / 4.0
			draw_circle(Vector2(bx, a.position.y + 2.0), 2.0, Color(0.72, 1.0, 0.18, 0.95))
	for s in _strips:
		if s[3]:
			_draw_strip(s)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for body in _wall_bodies:
		draw_texture_rect(wall_tex, body, true)
	for s in _strips:
		if not s[3]:
			_draw_strip(s)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_strip(s: Array) -> void:
	var length: float = s[2]
	var n := maxi(1, roundi(length / SPIKE))
	var w := length / n
	draw_set_transform(s[0], s[1], Vector2.ONE)
	for i in n:
		draw_texture_rect(spike_tex, Rect2(i * w, -SPIKE, w, SPIKE), false)
