extends Sprite2D
## A chasing smiley. They never run away: they come straight at you, and several can be
## alive at once (main.gd adds more as you get further). Touching one = -30 HP.
## One sword hit kills a smiley.

signal hit_player(damage: int)

const SPEED := 64.0
const DAMAGE := 30
const HIT_DIST := 16.0
const ANIM_FPS := 10.0
const FRAME_COUNT := 10
const MAX_LAG := 330.0

var player: Node2D = null
var anim_t := 0.0
var t := 0.0
var knock := Vector2.ZERO
var stun := 0.0
var hp := 1
var dying := false


func setup(p: Node2D) -> void:
	player = p
	z_index = 20


func _ready() -> void:
	add_to_group("enemies")
	add_to_group("hazards")
	add_to_group("chasers")
	anim_t = randf() * FRAME_COUNT
	t = randf() * 6.0
	scale = Vector2(0.01, 0.01)
	create_tween().tween_property(self, "scale", Vector2.ONE, 0.2)


func freeze() -> void:
	set_process(false)


func take_hit(dmg: int) -> void:
	if dying:
		return
	hp -= dmg
	var away := global_position - player.global_position
	knock = away.normalized() * 220.0
	if hp <= 0:
		dying = true
		remove_from_group("enemies")
		remove_from_group("hazards")
		remove_from_group("chasers")
		set_process(false)
		var tw := create_tween()
		tw.tween_property(self, "scale", Vector2(1.6, 1.6), 0.15)
		tw.parallel().tween_property(self, "modulate:a", 0.0, 0.15)
		tw.tween_callback(queue_free)


func _process(delta: float) -> void:
	t += delta
	stun = maxf(stun - delta, 0.0)
	var to_player := player.global_position - global_position
	var dist := to_player.length()
	if stun <= 0.0 and dist > 2.0:
		position += to_player / dist * SPEED * delta
	position += knock * delta
	knock = knock.move_toward(Vector2.ZERO, 500.0 * delta)
	position.y += sin(t * 4.0) * 10.0 * delta

	anim_t += delta * ANIM_FPS
	frame = int(anim_t) % FRAME_COUNT

	if dist < HIT_DIST and stun <= 0.0:
		hit_player.emit(DAMAGE)
		stun = 0.35                               # tiny pause, then right back at you
		knock = -to_player.normalized() * 70.0

	# if the player outruns it, it reappears ahead so the chase never ends
	if to_player.x < -MAX_LAG:
		position = Vector2(player.global_position.x + 240.0, randf_range(30.0, 130.0))
