extends Node2D
## Sword swing. The player calls swing(facing) with 1 (right) or -1 (left).

func _ready() -> void:
	visible = false


func swing(facing: int) -> void:
	position.x = 4.0 * facing
	scale.x = float(facing)
	visible = true
	rotation = -1.9 * facing
	var tw := create_tween()
	tw.tween_property(self, "rotation", 1.7 * facing, 0.18) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_callback(hide)
