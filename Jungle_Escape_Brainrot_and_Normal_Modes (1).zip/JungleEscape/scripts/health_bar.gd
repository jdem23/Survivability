extends Sprite2D
## Health bar sheet (3 x 4 cells). Picks the frame closest to your health %, and steps
## through frames so the bar visibly drains/refills. Frame 7 = empty, 8-9 = broken.

const FILLS := [1.0, 0.88, 0.70, 0.55, 0.41, 0.30, 0.18]   # how full frames 0..6 are

var target_frame := 0
var step_timer := 0.0
var locked := false


func frame_for(fraction: float) -> int:
	if fraction <= 0.0:
		return 7
	var best := 0
	var best_d := 9.0
	for i in FILLS.size():
		var d := absf(FILLS[i] - fraction)
		if d < best_d:
			best_d = d
			best = i
	return best


func set_health(h: int, instant := false) -> void:
	target_frame = frame_for(float(h) / 100.0)
	if instant:
		frame = target_frame


func shatter() -> void:
	locked = true
	while frame < 7:
		frame += 1
		await get_tree().create_timer(0.06).timeout
	await get_tree().create_timer(0.2).timeout
	frame = 8
	await get_tree().create_timer(0.15).timeout
	frame = 9


func _process(delta: float) -> void:
	if locked:
		return
	step_timer += delta
	if step_timer < 0.05:
		return
	step_timer = 0.0
	if frame < target_frame:
		frame += 1
	elif frame > target_frame:
		frame -= 1
