extends Node2D
## Jungle Escape - game controller.
##  - Run right to the EXIT. Joystick: left/right = run, up = fly. Tap/click outside the joystick to swing.
##  - Smileys chase you relentlessly (-30 HP each hit). Purple monsters shoot lightning (-10 HP).
##  - Any spike = instant death. Crates are solid; some are covered in spikes.
## Normal mode is quiet; Brainrot mode restores the chaotic sounds and trails.

const MAX_HEALTH := 100
const SACK_HEAL := 13
const LEVEL_WIDTH := 5400.0
const FINISH_X := LEVEL_WIDTH - 50.0
const MAX_SACKS := 3
const MAX_CHASERS := 3
const SACK_MAX_Y := 150.0
const PICKUP_DIST := 20.0

var sack_scene: PackedScene = preload("res://scenes/Sack.tscn")
var chaser_scene: PackedScene = preload("res://scenes/Chaser.tscn")
var shooter_scene: PackedScene = preload("res://scenes/Shooter.tscn")
var bolt_scene: PackedScene = preload("res://scenes/Bolt.tscn")
var witch_scene: PackedScene = preload("res://scenes/Witch.tscn")
var vial_scene: PackedScene = preload("res://scenes/PoisonVial.tscn")

@onready var level = $Level
@onready var player: CharacterBody2D = $Player
@onready var sacks: Node2D = $Sacks
@onready var hazards: Node2D = $Hazards
@onready var sack_timer: Timer = $SackTimer
@onready var shooter_timer: Timer = $ShooterTimer
@onready var chaser_timer: Timer = $ChaserTimer
@onready var witch_timer: Timer = $WitchTimer
@onready var health_bar = $UI/HealthBar
@onready var hp_label: Label = $UI/HpLabel
@onready var progress_label: Label = $UI/ProgressLabel
@onready var hint_label: Label = $UI/HintLabel
@onready var flash: ColorRect = $UI/Flash
@onready var game_over = $UI/GameOver
@onready var joystick = $UI/Joystick

var brainrot_mode := false
var menu_open := true
var menu_layer: Control
var health := MAX_HEALTH
var state := "playing"        # "playing", "dead", "won"
var shooter: Node2D = null
var rng := RandomNumberGenerator.new()
var acid_contact_tick := 0.0
var acid_after_timer := 0.0
var acid_after_tick := 0.0
var poison_time := 0.0
var poison_tick := 0.0


func _ready() -> void:
	_setup_input()
	rng.randomize()
	level.build()
	player.joystick = joystick
	game_over.visible = false
	_create_mode_menu()
	health_bar.set_health(health, true)
	_refresh_hud()
	sack_timer.timeout.connect(_on_sack_timer_timeout)
	shooter_timer.timeout.connect(_on_shooter_timer_timeout)
	chaser_timer.timeout.connect(_on_chaser_timer_timeout)
	witch_timer.timeout.connect(_on_witch_timer_timeout)
	sack_timer.stop()
	shooter_timer.stop()
	chaser_timer.stop()
	witch_timer.stop()
	hint_label.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(8.0)
	tw.tween_property(hint_label, "modulate:a", 0.0, 1.0)



func _create_mode_menu() -> void:
	menu_layer = Control.new()
	menu_layer.name = "ModeSelect"
	menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	$UI.add_child(menu_layer)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.025, 0.06, 0.045, 0.96)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_layer.add_child(shade)
	var title := Label.new()
	title.text = "JUNGLE ESCAPE"
	title.position = Vector2(20, 28)
	title.size = Vector2(320, 38)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26)
	menu_layer.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "CHOOSE YOUR MODE"
	subtitle.position = Vector2(20, 68)
	subtitle.size = Vector2(320, 24)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 14)
	menu_layer.add_child(subtitle)
	var normal := Button.new()
	normal.text = "NORMAL MODE\nQuiet • No trails • No sounds"
	normal.position = Vector2(44, 102)
	normal.size = Vector2(272, 48)
	normal.add_theme_font_size_override("font_size", 13)
	normal.pressed.connect(func(): _start_mode(false))
	menu_layer.add_child(normal)
	var brainrot := Button.new()
	brainrot.text = "BRAINROT MODE 💀\nFart & pee trails • All sounds & music"
	brainrot.position = Vector2(44, 160)
	brainrot.size = Vector2(272, 52)
	brainrot.add_theme_font_size_override("font_size", 12)
	brainrot.pressed.connect(func(): _start_mode(true))
	menu_layer.add_child(brainrot)

func _start_mode(use_brainrot: bool) -> void:
	brainrot_mode = use_brainrot
	menu_open = false
	menu_layer.queue_free()
	player.brainrot_mode = brainrot_mode
	if brainrot_mode:
		$Music.play()
		$Music.finished.connect(func(): if brainrot_mode and is_inside_tree(): $Music.play())
	else:
		$Music.stop()
		player.set_brainrot_effects(false)
	sack_timer.start(6.0)
	shooter_timer.start(8.0)
	chaser_timer.start(3.0)
	witch_timer.start(12.0)

# ---------------------------------------------------------------- input
func _setup_input() -> void:
	_set_key_action("move_up", [KEY_W, KEY_UP, KEY_SPACE])
	_set_key_action("move_down", [KEY_S, KEY_DOWN])
	_set_key_action("move_left", [KEY_A, KEY_LEFT])
	_set_key_action("move_right", [KEY_D, KEY_RIGHT])
	_set_key_action("restart", [KEY_R])


func _set_key_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	InputMap.action_erase_events(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


func _input(event: InputEvent) -> void:
	if state == "playing":
		return
	if not game_over.visible:
		return
	if event.is_action_pressed("restart"):
		get_tree().reload_current_scene()
	elif event is InputEventMouseButton and event.pressed:
		get_tree().reload_current_scene()
	elif event is InputEventScreenTouch and event.pressed:
		get_tree().reload_current_scene()


# ---------------------------------------------------------------- loop
func _process(_delta: float) -> void:
	if menu_open or state != "playing":
		return
	var px: float = player.global_position.x
	var pct: int = clampi(int(px / FINISH_X * 100.0), 0, 100)
	progress_label.text = "Escape: %d%%" % pct

	# spikes (floor patches, ceiling, walls, spiked crates)
	var prect := Rect2(player.global_position + Vector2(-5.0, -12.0), Vector2(10.0, 25.0))
	for r in level.spike_rects:
		if prect.intersects(r):
			_die("Impaled on spikes!")
			return

	if px >= FINISH_X:
		_win()
		return

	_update_environment_damage(get_process_delta_time())

	if health < MAX_HEALTH:
		for s in sacks.get_children():
			if s.collected:
				continue
			if player.global_position.distance_to(s.global_position) < PICKUP_DIST:
				s.collect()
				health = mini(health + SACK_HEAL, MAX_HEALTH)
				health_bar.set_health(health)
				_refresh_hud()
				break


func _refresh_hud() -> void:
	hp_label.text = "HP %d" % health


# ---------------------------------------------------------------- damage
func _on_player_hit(damage: int, bypass_invulnerability: bool = false) -> void:
	if state != "playing" or (player.is_invulnerable() and not bypass_invulnerability):
		return
	health = maxi(health - damage, 0)
	health_bar.set_health(health)
	_refresh_hud()
	player.hurt()
	flash.modulate.a = 0.5
	var tw := create_tween()
	tw.tween_property(flash, "modulate:a", 0.0, 0.3)
	if health <= 0:
		_die("You died")


func _die(message: String) -> void:
	if state != "playing":
		return
	state = "dead"
	_stop_everything()
	player.die()
	health_bar.shatter()
	await get_tree().create_timer(1.2).timeout
	game_over.play(message, Color(1.0, 0.45, 0.45))


func _win() -> void:
	state = "won"
	_stop_everything()
	player.finish()
	await get_tree().create_timer(0.6).timeout
	game_over.play("YOU PASSED! You escaped the jungle.", Color(0.6, 1.0, 0.6))


func _stop_everything() -> void:
	sack_timer.stop()
	shooter_timer.stop()
	chaser_timer.stop()
	witch_timer.stop()
	get_tree().call_group("hazards", "freeze")


# ---------------------------------------------------------------- spawning
func _on_chaser_timer_timeout() -> void:
	if state != "playing":
		return
	# more smileys the further you get: 1 at the start, up to 3
	var wanted: int = mini(1 + int(player.global_position.x / FINISH_X * 3.0), MAX_CHASERS)
	if get_tree().get_nodes_in_group("chasers").size() >= wanted:
		return
	var from_behind := rng.randf() < 0.4
	var x: float = player.global_position.x + (-260.0 if from_behind else 260.0)
	x = clampf(x, 20.0, LEVEL_WIDTH - 30.0)
	var c = chaser_scene.instantiate()
	c.setup(player)
	c.position = Vector2(x, rng.randf_range(30.0, 120.0))
	hazards.add_child(c)
	c.hit_player.connect(_on_player_hit)


func _on_shooter_timer_timeout() -> void:
	if state != "playing" or shooter != null:
		return
	var s = shooter_scene.instantiate()
	s.setup(player, rng.randf_range(45.0, 110.0), LEVEL_WIDTH)
	s.position = Vector2(player.global_position.x + 330.0, 60.0)
	hazards.add_child(s)
	s.fire_bolt.connect(_on_shooter_fire)
	s.tree_exited.connect(_on_shooter_gone)
	shooter = s


func _on_shooter_gone() -> void:
	shooter = null
	if state == "playing" and is_inside_tree():
		shooter_timer.start(rng.randf_range(9.0, 14.0))


func _on_shooter_fire(from_pos: Vector2) -> void:
	if state != "playing":
		return
	var dir: Vector2 = (player.global_position - from_pos).normalized()
	var b = bolt_scene.instantiate()
	b.setup(player, from_pos, dir)
	hazards.add_child(b)
	b.hit_player.connect(_on_player_hit)


func _on_sack_timer_timeout() -> void:
	if state != "playing":
		return
	for s in sacks.get_children():
		if s.global_position.x < player.global_position.x - 280.0:
			s.queue_free()
	if sacks.get_child_count() >= MAX_SACKS:
		return
	var pos := Vector2.ZERO
	for i in 30:
		pos = Vector2(
			minf(player.global_position.x + rng.randf_range(170.0, 300.0), LEVEL_WIDTH - 60.0),
			rng.randf_range(50.0, SACK_MAX_Y))
		if not level.is_blocked(pos):
			break
	var s = sack_scene.instantiate()
	s.position = pos
	sacks.add_child(s)


func _update_environment_damage(delta: float) -> void:
	var player_rect := Rect2(player.global_position + Vector2(-5.0, -12.0), Vector2(10.0, 25.0))
	var in_acid := false
	for a in level.acid_rects:
		if player_rect.intersects(a):
			in_acid = true
			break
	if in_acid:
		acid_after_timer = 5.0
		acid_after_tick += delta
		while acid_after_tick >= 1.0:
			acid_after_tick -= 1.0
			_on_player_hit(15, true)
	else:
		acid_after_timer = maxf(acid_after_timer - delta, 0.0)
		if acid_after_timer > 0.0:
			acid_after_tick += delta
			while acid_after_tick >= 1.0:
				acid_after_tick -= 1.0
				_on_player_hit(3, true)
		else:
			acid_after_tick = 0.0
	if poison_time > 0.0:
		poison_time = maxf(poison_time - delta, 0.0)
		poison_tick += delta
		while poison_tick >= 1.0 and poison_time > 0.0:
			poison_tick -= 1.0
			_on_player_hit(3, true)
	else:
		poison_tick = 0.0


func _on_witch_timer_timeout() -> void:
	if state != "playing": return
	# Keep a small group of witches active without flooding the screen.
	var active_witches := 0
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if enemy.has_method("setup") and enemy.has_method("take_hit") and enemy.get_script() == load("res://scripts/witch.gd"):
			active_witches += 1
	if active_witches < 1:
		var w = witch_scene.instantiate()
		w.setup(player, rng.randf_range(45.0, 105.0), LEVEL_WIDTH)
		w.position = Vector2(minf(player.global_position.x + rng.randf_range(210.0, 330.0), LEVEL_WIDTH - 35.0), rng.randf_range(45.0, 105.0))
		hazards.add_child(w)
		w.throw_vial.connect(_on_witch_throw_vial)
	witch_timer.start(rng.randf_range(12.0, 16.0))


func _on_witch_throw_vial(from_pos: Vector2) -> void:
	if state != "playing": return
	var vial = vial_scene.instantiate()
	vial.setup(player, from_pos)
	hazards.add_child(vial)
	vial.hit_player.connect(_on_poison_vial_hit)


func _on_poison_vial_hit(damage: int, dps: int, seconds: float) -> void:
	_on_player_hit(damage, true)
	poison_time = maxf(poison_time, seconds)
	poison_tick = 0.0

