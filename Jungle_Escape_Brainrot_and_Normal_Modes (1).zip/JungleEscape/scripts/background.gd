extends Node2D
## Tiles the forest background across the whole level. Every second tile is mirrored
## so the seams line up perfectly.

const TILE_W := 360
const TILES := 15     # 15 * 360 = 5400 px level
var tex: Texture2D = preload("res://assets/BackGround_001.png")


func _ready() -> void:
	for i in TILES:
		var s := Sprite2D.new()
		s.texture = tex
		s.centered = false
		s.position = Vector2(i * TILE_W, 0)
		s.flip_h = (i % 2 == 1)
		add_child(s)
