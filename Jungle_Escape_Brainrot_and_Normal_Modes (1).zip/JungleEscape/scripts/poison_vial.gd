extends Node2D
signal hit_player(damage: int, poison_dps: int, poison_seconds: float)
const SPEED := 125.0
const HIT_RADIUS := 13.0
const LIFETIME := 5.0
var player: Node2D
var vel := Vector2.ZERO
var age := 0.0
func setup(p: Node2D, from_pos: Vector2) -> void:
	player = p
	global_position = from_pos
	vel = (p.global_position - from_pos).normalized() * SPEED
	z_index = 40
func _ready() -> void:
	add_to_group("hazards")
	queue_redraw()
func freeze() -> void:
	set_process(false)
func _process(delta: float) -> void:
	age += delta
	position += vel * delta
	rotation += delta * 5.0
	if player and global_position.distance_to(player.global_position) < HIT_RADIUS:
		hit_player.emit(50, 3, 5.0)
		queue_free()
	elif age > LIFETIME:
		queue_free()
	queue_redraw()
func _draw() -> void:
	# Bright glass bottle with cork and a toxic-green core.
	draw_colored_polygon(PackedVector2Array([Vector2(-4,-7),Vector2(4,-7),Vector2(5,-2),Vector2(6,5),Vector2(3,8),Vector2(-3,8),Vector2(-6,5),Vector2(-5,-2)]), Color(0.55,0.95,0.85,0.9))
	draw_rect(Rect2(-4,0,8,6), Color(0.30,1.0,0.04,1.0))
	draw_rect(Rect2(-2,-11,4,4), Color(0.45,0.20,0.08))
	draw_line(Vector2(-2,-4), Vector2(1,-1), Color(1,1,1,0.9), 1.5)
